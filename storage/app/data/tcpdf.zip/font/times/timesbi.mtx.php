<?php
$name='TimesNewRomanPS-BoldItalicMT';
$type='TTF';
$desc=array (
  'Ascent' => 891.0,
  'Descent' => -216.0,
  'CapHeight' => 662.0,
  'Flags' => 262212,
  'FontBBox' => '[-547 -307 1401 1032]',
  'ItalicAngle' => -16.332992553710938,
  'StemV' => 165.0,
  'MissingWidth' => 778.0,
);
$up=-109;
$ut=95;
$ttffile='/home/cpchncom/public_html/wp-content/themes/CPC1HN_Flyer/tfpdf/font/unifont/timesbi.ttf';
$originalsize=610820;
$fontkey='timesbi';
?>