<?php
$name='TimesNewRomanPS-ItalicMT';
$type='TTF';
$desc=array (
  'Ascent' => 891.0,
  'Descent' => -216.0,
  'CapHeight' => 662.0,
  'Flags' => 68,
  'FontBBox' => '[-498 -307 1353 1023]',
  'ItalicAngle' => -16.332992553710938,
  'StemV' => 87.0,
  'MissingWidth' => 778.0,
);
$up=-109;
$ut=49;
$ttffile='/home/cpchncom/public_html/wp-content/themes/CPC1HN_Flyer/tfpdf/font/unifont/timesi.ttf';
$originalsize=651500;
$fontkey='timesi';
?>