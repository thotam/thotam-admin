<?php
$name='TimesNewRomanPS-BoldMT';
$type='TTF';
$desc=array (
  'Ascent' => 891.0,
  'Descent' => -216.0,
  'CapHeight' => 662.0,
  'Flags' => 262148,
  'FontBBox' => '[-558 -307 2000 1026]',
  'ItalicAngle' => 0.0,
  'StemV' => 165.0,
  'MissingWidth' => 778.0,
);
$up=-109;
$ut=95;
$ttffile='/home/cpchncom/public_html/wp-content/themes/CPC1HN_Flyer/tfpdf/font/unifont/timesbd.ttf';
$originalsize=835868;
$fontkey='timesbd';
?>