<?php
$name='TimesNewRomanPSMT';
$type='TTF';
$desc=array (
  'Ascent' => 891.0,
  'Descent' => -216.0,
  'CapHeight' => 662.0,
  'Flags' => 4,
  'FontBBox' => '[-568 -307 2000 1007]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 778.0,
);
$up=-109;
$ut=49;
$ttffile='/home/cpchncom/public_html/wp-content/themes/CPC1HN_Flyer/tfpdf/font/unifont/times.ttf';
$originalsize=828152;
$fontkey='times';
?>